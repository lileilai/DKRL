
---

FB20K

new-added entities with their names, descriptions and triples



---